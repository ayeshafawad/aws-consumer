require 'test_helper'

class PolicyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
