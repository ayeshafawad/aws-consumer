require 'test_helper'

class MediaHelperTest < ActionView::TestCase
end
