require 'test_helper'

class BucketsHelperTest < ActionView::TestCase
end
