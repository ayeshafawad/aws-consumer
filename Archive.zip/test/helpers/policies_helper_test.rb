require 'test_helper'

class PoliciesHelperTest < ActionView::TestCase
end
