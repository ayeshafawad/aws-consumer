class Dynamotable < ActiveRecord::Base
end
