class Bucket < ActiveRecord::Base
end
