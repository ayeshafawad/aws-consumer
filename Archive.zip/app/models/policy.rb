class Policy < ActiveRecord::Base
end
